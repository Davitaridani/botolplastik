# BotolPlastik

Ini adalah repository untuk website BotolPlastik yang dibuat menggunakan Lumen framework.

## Catatan

- Untuk editing CSS, gunakan file custom.scss yang berada di folder `resources/scss` (Perlu sass compiler).
- File data produk, data kategori dll disimpan dalam format JSON di folder `resources/data`.

## License

The Lumen framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).

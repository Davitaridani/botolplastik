

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="bg-blue-banner mb-40">
  <div class="container d-flex flex-column">
    <div class="carousel slide mb-75" id="productSlider" data-bs-ride="carousel">
      <div class="carousel-indicators d-flex justify-content-start">
        <div class="indicator-item d-none d-xl-block">
          <?php for($i = 0; $i < 4; $i++): ?> <button type="button" data-bs-target="#productSlider" data-bs-slide-to="<?php echo e($i); ?>"
            class="<?php echo e($i == 0 ? 'active' : ''); ?>" aria-label="Slide <?php echo e($i); ?>"></button>
            <?php endfor; ?>
        </div>
      </div>
      <div class="carousel-inner text-white h-100">
        <?php for($i = 0; $i < 4; $i++): ?>
        <div class="carousel-item <?php echo e($i == 0 ? 'active' : ''); ?>">
          <img src="https://via.placeholder.com/1440x793/f4efe6/909090?text=Slide+Image+Cover" class="d-block w-100"
            alt="...">
        </div>
        <?php endfor; ?>
      </div>
    </div>

    <div class="mb-75 text-center text-white ">
      <h1 class="fs-30 fw-bold">Koleksi Botol Plastik</h1>
    </div>
  </div>
</section>
<main class="container d-flex flex-column">
  <section class="d-flex justify-content-center text-center fw-bold container px-4 fs-15 mb-30 sticky-below-nav bg-white">
    <p class="border-3 px-3 border-end-blue-dark"><a href="#" class="text-decoration-none link-hover-lainnya text-blue-dark">All Products</a></p>
    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p class="border-3 px-3 <?php echo e($item == end($kategori) ? '' : 'border-end-blue-dark'); ?>">
      <a href="<?php echo e($item['link']); ?>" class="text-decoration-none link-hover text-blue-dark"><?php echo e($item['name']); ?></a>
    </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </section>
  <section class="border-top border-bottom row align-items-center mb-75 py-2">
    <span class="col-auto">
      <p class="fs-13 fw-medium mb-0 text-blue-dark">Filter berdasar:</p>
    </span>
    <span class="col-auto">
      <p class="fs-13 fw-medium mb-0 text-blue-dark">Aplikasi</p>
    </span>
    <span class="col-auto">
      <select name="filter-application" id="filter-select" class="form-select">
        <?php $__currentLoopData = $aplikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($item['name']); ?>"><?php echo e($item['name']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </span>
    <span class="col-auto fs-13 fw-medium hstack">
      <div class="border-2 border-end-blue-dark px-3">
        <a href="#" class="text-decoration-none text-blue-dark link-hover">Terbaru</a>
      </div>
      <div class="border-2 border-end-blue-dark px-3">
        <a href="#" class="text-decoration-none text-blue-dark link-hover">Terlama</a>
      </div>
      <div class="px-3">
        <a href="#" class="text-decoration-none text-blue-dark link-hover">Paling Laris</a>
      </div>
    </span>
    <span class="col fs-13 fw-medium d-flex justify-content-end">
      <p class="mb-0 float-right">Menampilkan <?php echo e(count($produk)); ?> produk</p>
    </span>
  </section>
  <section class="px-md-5 mb-120">
    <div class="row px-md-3 mx-1 row-cols-2 row-cols-lg-4 g-2 g-lg-5 ">
      <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col">
        <div class="card bg-white border-0 mb-4 mb-md-0">
          <img src="<?php echo e(url($items['image'])); ?>" class="card-img-top" alt="...">
          <div class="card-body text-center">
            <h6 class="card-title text-primary fw-bold py-24 fs-18"><?php echo e($items["name"]); ?></h6>
            <a href="products/details/<?php echo e($key); ?>" class="btn btn-primary  fw-bold fs-15">Lihat Produk</a>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </section>
  <?php echo $__env->make('includes._customers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</main>
<?php echo $__env->make('includes._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\botolplastik\resources\views/products.blade.php ENDPATH**/ ?>